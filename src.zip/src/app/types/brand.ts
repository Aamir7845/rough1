export interface Brand {
  _id?: string;
  name: string;
}
